# AUI TabView

> Documentation and test modifications are not included in this changelog. For more details, see [full commit history](https://github.com/liferay/alloy-ui/commits/master/src/aui-tabview).

## @VERSION@

No registries yet.

## [3.0.1](https://github.com/liferay/alloy-ui/releases/tag/3.0.1)

No changes.

## [3.0.0](https://github.com/liferay/alloy-ui/releases/tag/3.0.0)

* [AUI-1303](https://issues.liferay.com/browse/AUI-1303) Make aui-form-builder responsive
* [AUI-1287](https://issues.liferay.com/browse/AUI-1287) Wrong css formatting when running "grunt format"
* [AUI-1098](https://issues.liferay.com/browse/AUI-1098) Upgrade to Bootstrap 3
* [AUI-1267](https://issues.liferay.com/browse/AUI-1267) Move CSS classes from Alloy Bootstrap to AlloyUI
* [AUI-1252](https://issues.liferay.com/browse/AUI-1252) Fix cursors on dynamic generated tabs
* [AUI-1246](https://issues.liferay.com/browse/AUI-1246) Fix border issue with stacked TabView

## [2.5.0](https://github.com/liferay/alloy-ui/releases/tag/2.5.0)

* [AUI-1163](https://issues.liferay.com/browse/AUI-1163) Remove unnecessary constants